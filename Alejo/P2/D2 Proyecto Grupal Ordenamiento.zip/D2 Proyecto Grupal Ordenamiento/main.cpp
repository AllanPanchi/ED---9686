/*
UNIVERSIDAD DE LAS FUERZAS ARMADAS ESPE
Materia: Estructura de Datos
NRC: 9686
Integrantes:    Alejandro Andrade
                Allan Panchi
                Alex Trejo 
                Sebastian Verdugo
Fecha de inicio: 15/06/2023
Fecha de modificación: 15/06/2023

Ordenamiento de lista circular doblemente enlazadas
*/

#include "Aplication.cpp"
#include "Aplication.h"
#include "menu.cpp"
#include "Menu.h"
#include <iostream>

int main(int argc, char **argv) {

    Aplication aplication;

    aplication.run();

    return 0;

}
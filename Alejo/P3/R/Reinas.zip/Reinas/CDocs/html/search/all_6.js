var searchData=
[
  ['getarchivo_0',['getArchivo',['../class_alfil.html#ab8b5fe93bca14ba4b52b7476af191a59',1,'Alfil::getArchivo()'],['../class_reina.html#ad07578849f2589d7644e61e2adf4c97b',1,'Reina::getArchivo()']]],
  ['getcontador_1',['getContador',['../class_alfil.html#abefdb946460d80b8c14e927c4ceeef94',1,'Alfil::getContador()'],['../class_reina.html#aa240eadcfbff5d0045fdc7923baa7952',1,'Reina::getContador()']]],
  ['getn_2',['getN',['../class_alfil.html#adb8e170cc1cf4300e645e32c332142dd',1,'Alfil::getN()'],['../class_reina.html#ab37532709b584aa8259c29ed2674d954',1,'Reina::getN()']]],
  ['gettablero_3',['getTablero',['../class_alfil.html#afc39426b45cf5bc43c8d1a82e79c5727',1,'Alfil::getTablero()'],['../class_reina.html#a31120b5cd4e93535611ed28937dd833e',1,'Reina::getTablero()']]],
  ['getvalidar_4',['getValidar',['../class_alfil.html#ac9a1ef279789aa74681f086ee63fc4c6',1,'Alfil::getValidar()'],['../class_reina.html#a4573803140861148370a2ebb3037db6e',1,'Reina::getValidar()']]]
];

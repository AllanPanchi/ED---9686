var searchData=
[
  ['mostrar_0',['mostrar',['../class_alfil.html#ac0cd6b81caf40a9f91c99b5586002e08',1,'Alfil::mostrar()'],['../class_funcion_a.html#a275d4399b6f2252b4e40e7e557a0cd55',1,'FuncionA::mostrar()'],['../class_funciones_interfaz.html#aab82002af864d9b27e9750def53ec0bf',1,'FuncionesInterfaz::mostrar()'],['../class_tablero.html#ae4392f69513182d3f402600b017f07f6',1,'Tablero::mostrar()']]],
  ['mostraralfil_1',['mostrarAlfil',['../class_funcion_a.html#a478a36ace70bc2d2411315b4b65b6f4b',1,'FuncionA']]]
];

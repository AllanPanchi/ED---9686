var searchData=
[
  ['alfil_0',['Alfil',['../class_alfil.html',1,'Alfil'],['../class_alfil.html#ac40b010711a776348a1f808f557301cd',1,'Alfil::Alfil()']]],
  ['alfil_2eh_1',['Alfil.h',['../_alfil_8h.html',1,'']]]
];

var searchData=
[
  ['_7ealfil_0',['~Alfil',['../class_alfil.html#a79c348c8bf35ec185a5952e1b1448627',1,'Alfil']]],
  ['_7ereina_1',['~Reina',['../class_reina.html#a956e1b4cab44451bcbd9d07f80e6d5e4',1,'Reina']]]
];

var searchData=
[
  ['alfil_0',['Alfil',['../class_alfil.html#ac40b010711a776348a1f808f557301cd',1,'Alfil']]]
];

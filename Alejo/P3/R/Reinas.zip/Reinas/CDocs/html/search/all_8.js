var searchData=
[
  ['quitarrelleno_0',['quitarRelleno',['../class_alfil.html#ac85ca94371a7240f7fe7115099c8997d',1,'Alfil::quitarRelleno()'],['../class_funcion_a.html#ab05d31616825a38500687c3e21269c17',1,'FuncionA::quitarRelleno()'],['../class_funciones_interfaz.html#aa4a46f3d0a3a891bad7e78498f1a35c2',1,'FuncionesInterfaz::quitarRelleno()'],['../class_tablero.html#a4e71e5f13d64001f301084b91dd5c22b',1,'Tablero::quitarRelleno()']]]
];

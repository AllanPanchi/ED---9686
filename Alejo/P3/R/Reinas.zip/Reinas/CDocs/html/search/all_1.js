var searchData=
[
  ['bloquear_0',['bloquear',['../class_alfil.html#ab37601aa8c96793a807caf59e32e066e',1,'Alfil::bloquear()'],['../class_funcion_a.html#a47bf898c59a46a0e0e1b55ef4ddc05de',1,'FuncionA::bloquear()'],['../class_funciones_interfaz.html#a39e0d6ea6a8595a58a4f8035bd67b030',1,'FuncionesInterfaz::bloquear()'],['../class_tablero.html#affe321bde6901ad4f4cc6cfb6941faa7',1,'Tablero::bloquear()']]],
  ['bloquearalfiles_1',['bloquearAlfiles',['../class_funcion_a.html#a1284310afa509925ae610871aca89e98',1,'FuncionA']]]
];

var searchData=
[
  ['funciona_0',['FuncionA',['../class_funcion_a.html',1,'FuncionA'],['../class_funcion_a.html#a92f63f5fe88f913ecc0a1711f3a47245',1,'FuncionA::FuncionA()']]],
  ['funciona_2eh_1',['FuncionA.h',['../_funcion_a_8h.html',1,'']]],
  ['funcionesinterfaz_2',['FuncionesInterfaz',['../class_funciones_interfaz.html',1,'FuncionesInterfaz'],['../class_funciones_interfaz.html#af49163d1c93ac1f797de265fa6dec968',1,'FuncionesInterfaz::FuncionesInterfaz()']]],
  ['funcionesinterfaz_2eh_3',['FuncionesInterfaz.h',['../_funciones_interfaz_8h.html',1,'']]]
];

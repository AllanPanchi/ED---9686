var searchData=
[
  ['setarchivo_0',['setArchivo',['../class_alfil.html#a0ec5715b529760d6f9cf7a9a21524054',1,'Alfil::setArchivo()'],['../class_reina.html#a3a5b9c6333e5c604676dd4921319552a',1,'Reina::setArchivo()']]],
  ['setcontador_1',['setContador',['../class_alfil.html#a3d6ad7322951cb793081e1994bf96fc6',1,'Alfil::setContador()'],['../class_reina.html#aabfcf351117876ac2e3ba0d04cc8219a',1,'Reina::setContador()']]],
  ['setn_2',['setN',['../class_alfil.html#a0999a25d36cc37a4af42d3adcb43ca3d',1,'Alfil::setN()'],['../class_reina.html#a16a855c3b460690cd87252252dc13791',1,'Reina::setN()']]],
  ['settablero_3',['setTablero',['../class_alfil.html#a80d4c019038d65b4a37ba003d5044983',1,'Alfil::setTablero()'],['../class_reina.html#a9ced7ec7abf31e1e0e47ab7b59ecdd93',1,'Reina::setTablero()']]],
  ['setvalidar_4',['setValidar',['../class_alfil.html#ab6d08e48fbb0a9491b4752516eb02ae0',1,'Alfil::setValidar()'],['../class_reina.html#a9a66d10cf7ed3f3cbd675fe1fa1b88a0',1,'Reina::setValidar()']]],
  ['solucion_5',['solucion',['../class_alfil.html#ac1a07f9d36ee52876c8dfd498f5ad390',1,'Alfil::solucion()'],['../class_funcion_a.html#a794cb38a0ce664c45767cea2365db3ff',1,'FuncionA::solucion()'],['../class_funciones_interfaz.html#a5cc4c015aa2e4d674221e3de08fed01f',1,'FuncionesInterfaz::solucion()'],['../class_tablero.html#ad475508ed300bf24bb53296aeee854f9',1,'Tablero::solucion()']]],
  ['solucionalfila_6',['solucionAlfilA',['../class_funcion_a.html#a84dcd408833bc1c3dbbf07a5d0da5834',1,'FuncionA']]],
  ['solucionalfiles_7',['solucionAlfiles',['../class_funcion_a.html#a640b7a1b3806ec9f9eeac51c000f23c1',1,'FuncionA']]],
  ['solucionreinas_8',['solucionReinas',['../class_alfil.html#a29c7aeef8f30c7251142730fdfab5480',1,'Alfil::solucionReinas()'],['../class_funcion_a.html#aedea0b78636fbc6f7d423842d8790ac0',1,'FuncionA::solucionReinas()'],['../class_funciones_interfaz.html#abaa1d702775ff02b548ed7eba9c6e95c',1,'FuncionesInterfaz::solucionReinas()'],['../class_tablero.html#a6432b8ca3cbc9a9d73404a0927073c89',1,'Tablero::solucionReinas()']]]
];

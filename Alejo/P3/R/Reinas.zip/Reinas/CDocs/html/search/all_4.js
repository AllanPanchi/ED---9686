var searchData=
[
  ['encerartablero_0',['encerarTablero',['../class_alfil.html#a6f5b2bbfad3305f08a1941875bed6478',1,'Alfil::encerarTablero()'],['../class_funcion_a.html#a15a9b3bca4134f84d80eddec52e420f8',1,'FuncionA::encerarTablero()'],['../class_funciones_interfaz.html#a746f4e91fdf4b1037257226ea4955708',1,'FuncionesInterfaz::encerarTablero()'],['../class_tablero.html#aba9c558ae6952ce84f3fa848f54ab420',1,'Tablero::encerarTablero()']]]
];

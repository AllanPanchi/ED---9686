var searchData=
[
  ['funciona_0',['FuncionA',['../class_funcion_a.html',1,'']]],
  ['funcionesinterfaz_1',['FuncionesInterfaz',['../class_funciones_interfaz.html',1,'']]]
];

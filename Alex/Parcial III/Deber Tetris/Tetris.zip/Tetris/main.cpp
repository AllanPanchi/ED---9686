#include "Juego.cpp"

int main(){
    Juego juego;
    juego.ejecutar();
}
#include <iostream>
#include "Producto.h"

        // Producto::Producto(int c, std::string n, float p,int aE,int aC) {
        //     this->codigo = c;
        //     this->nombre = n;
        //     this->precio = p;
        //     this->anioElaboracion = aE;
        //     this->anioCaducidad = aC;
        // }

        // Producto::Producto() : codigo(0), nombre(""), precio(0.0), anioElaboracion(0), anioCaducidad(0) {}

        // Producto::~Producto() {}

        // void Producto::setCodigo(int codigo) {
        //     this->codigo = codigo;
        // }

        // int Producto::getCodigo() {
        //     return codigo;
        // }

        // void Producto::setNombre(std::string nombre) {
        //     this->nombre = nombre;
        // }

        // std::string Producto::getNombre() {
        //     return nombre;
        // }

        // void Producto::setPrecio(float precio) {
        //     this->precio = precio;
        // }

        // float Producto::getPrecio() {
        //     return precio;
        // }

        // void Producto::setAnioElaboracion(int anioElaboracion) {
        //     this->anioElaboracion; //
        // }

        // int Producto::getAnioElaboracion() {
        //     return this->anioElaboracion;
        // }

        // void Producto::setAnioCaducidad(int anioCaducidad) {
        //     this->anioCaducidad = anioCaducidad;
        // }

        // int Producto::getAnioCaducidad() {
        //     return this->anioCaducidad;
        // }

        // void Producto::toString() {
        //     std::cout << "Codigo: " << this->codigo << std::endl;
        //     std::cout << "Nombre: " << this->nombre << std::endl;
        //     std::cout << "Precio: " << this->precio << std::endl;
        //     std::cout << "Anio de elaboracion: " << this->anioElaboracion << std::endl;
        //     std::cout << "Anio de caducidad: "<< this->anioCaducidad << std::endl;
        // }
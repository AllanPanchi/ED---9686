#include "FuncionesMenu.h"
#include "ValDatos.cpp"

// Producto FuncionesMenu::insertarProducto(ListaProducto lista)
// {
//     Producto producto;
//     producto.setCodigo(ValidarDatos::generarCodigoValidado(lista));
//     std::cout << "Ingrese el nombre del producto: ";
//     producto.setNombre(ValidarDatos::validarString());
//     std::cout << "Ingrese el precio del producto: ";
//     producto.setPrecio(ValidarDatos::validarFloat());
//     std::cout << "Ingrese el a\xC3\xB1o de elaboracion del producto" << std::endl;
//     producto.setAnioElaboracion(ValidarDatos::validarEntero());
//     std::cout << "Ingrese el a\xC3\xB1o de vencimiento del producto: " << std::endl;
//     producto.setAnioCaducidad(ValidarDatos::validarEntero());
    
//     return producto;
// }

// void FuncionesMenu::eliminarProducto()
// {
    
// }

// void FuncionesMenu::buscarProducto()
// {
    
// }

// void FuncionesMenu::mostrarProducto()
// {
   
// }
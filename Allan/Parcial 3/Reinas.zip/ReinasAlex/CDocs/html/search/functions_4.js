var searchData=
[
  ['funciona_0',['FuncionA',['../class_funcion_a.html#a92f63f5fe88f913ecc0a1711f3a47245',1,'FuncionA']]],
  ['funcionesinterfaz_1',['FuncionesInterfaz',['../class_funciones_interfaz.html#af49163d1c93ac1f797de265fa6dec968',1,'FuncionesInterfaz']]]
];
